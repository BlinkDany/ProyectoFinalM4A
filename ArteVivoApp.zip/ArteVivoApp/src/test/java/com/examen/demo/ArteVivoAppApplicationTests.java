package com.examen.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArteVivoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
