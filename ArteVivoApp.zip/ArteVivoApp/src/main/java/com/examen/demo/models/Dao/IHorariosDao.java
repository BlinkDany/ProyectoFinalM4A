package com.examen.demo.models.Dao;

import org.springframework.data.repository.CrudRepository;

import com.examen.demo.models.Entity.Horarios;

public interface IHorariosDao extends CrudRepository<Horarios, Long>{

}
