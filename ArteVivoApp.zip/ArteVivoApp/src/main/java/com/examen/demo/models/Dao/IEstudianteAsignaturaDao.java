package com.examen.demo.models.Dao;

import org.springframework.data.repository.CrudRepository;

import com.examen.demo.models.Entity.EstudianteAsignatura;

public interface IEstudianteAsignaturaDao extends CrudRepository<EstudianteAsignatura, Long>{

}
