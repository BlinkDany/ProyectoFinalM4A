package com.examen.demo.models.Dao;

import org.springframework.data.repository.CrudRepository;

import com.examen.demo.models.Entity.Asignatura;

public interface IAsignaturaDao extends CrudRepository<Asignatura,Long>{
	
}
