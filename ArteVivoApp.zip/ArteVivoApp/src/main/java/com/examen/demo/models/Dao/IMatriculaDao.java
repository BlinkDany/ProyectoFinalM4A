package com.examen.demo.models.Dao;

import org.springframework.data.repository.CrudRepository;

import com.examen.demo.models.Entity.Matricula;

public interface IMatriculaDao extends CrudRepository<Matricula, Long>{

}
